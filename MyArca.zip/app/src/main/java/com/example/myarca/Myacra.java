package com.example.myarca;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;

import org.acra.*;
import org.acra.annotation.*;
import org.acra.config.CoreConfigurationBuilder;
import org.acra.config.DialogConfigurationBuilder;
import org.acra.config.HttpSenderConfigurationBuilder;
import org.acra.config.MailSenderConfigurationBuilder;
import org.acra.data.StringFormat;
import org.acra.sender.EmailIntentSender;
import org.acra.sender.HttpSender;

@SuppressLint("ResourceType")
@AcraCore(buildConfigClass = BuildConfig.class,
        reportFormat = StringFormat.JSON)
@AcraHttpSender(uri = "보낼 서버 URL",
        httpMethod = HttpSender.Method.POST
)
@AcraDialog(resTitle =R.string.crash_dialog_title,
        resText =R.string.crash_dialog_text,
        resTheme = R.string.crash_dialog_title
)
@AcraMailSender(mailTo = "byw9206@gmail.com",
reportAsFile = false)
public class Myacra extends Application {
    @SuppressLint("ResourceType")
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        // 주석방식 말고 빌더 방식 사용시

//        CoreConfigurationBuilder builder = new CoreConfigurationBuilder(this)
//                .setBuildConfigClass(BuildConfig.class)
//                .setReportFormat(StringFormat.JSON);
//
//
//        builder.getPluginConfigurationBuilder(HttpSenderConfigurationBuilder.class)
//                .setHttpMethod(HttpSender.Method.POST)
//                .setUri("보낼서버 URL")
//                .setEnabled(true);
//
//        builder.getPluginConfigurationBuilder(DialogConfigurationBuilder.class)
//                .setResTitle(R.string.crash_dialog_title)
//                .setResTheme(R.string.crash_dialog_text)
//                .setText("앱의 비정상 정지되었습니다.")
//                .setEnabled(true);
//
//
//        builder.getPluginConfigurationBuilder(MailSenderConfigurationBuilder.class)
//                .setMailTo("byw9206@gmail.com")
//                .setSubject("에러리포트입니다.")
//                .setReportAsFile(true) //리포트를 파일형태로 보내면 사용자가 보고서를 수정 할 수 없다.
//                .setEnabled(true);
//
//
//        ACRA.init(this, builder);
        ACRA.init(this);
    }
}